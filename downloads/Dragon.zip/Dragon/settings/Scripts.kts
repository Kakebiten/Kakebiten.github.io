import com.charlatano.settings.*

/**
 * Enables the bunny hop script.
 *
 * When using "LEAGUE_MODE" you need to unbind the bunnyhop key,
 * and bind mwheelup and mwheeldown to jump.
 *
 * To do this, type the following commands into the in-game developer console:
 * unbind "space"
 * bind "mwheelup" "+jump"
 * bind "mwheeldown" "+jump"
 */
ENABLE_BUNNY_HOP = true

/**
 * Enables the recoil control system (RCS) script.
 */
ENABLE_RCS = true

/**
 * Enables the extra sensory perception (ESP) script.
 */
ENABLE_ESP = true

/**
 * Enables the flat aim script.
 *
 * This script uses traditional flat linear-regression smoothing.
 */
ENABLE_FLAT_AIM = true

/**
 * Enables the path aim script.
 *
 * This script uses an advanced path generation smoothing.
 */
ENABLE_PATH_AIM = false

/**
 * Enables the bone trigger bot script.
 */
ENABLE_BONE_TRIGGER = true

/**
 * Enables the reduced flash script.
 */
ENABLE_REDUCED_FLASH = true

/**
 * Enables the bomb timer script.
 */
ENABLE_BOMB_TIMER = true